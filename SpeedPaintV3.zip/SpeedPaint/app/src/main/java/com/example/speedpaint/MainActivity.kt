package com.example.speedpaint

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import kotlin.math.max

class MainActivity : Activity() {
    private var bitmap: Bitmap? = null
    private var resultUri: Uri? = null
    @Volatile private var cancelFlag = false

    private lateinit var preview: ImageView
    private lateinit var photoHint: TextView
    private lateinit var status: TextView
    private lateinit var generate: Button
    private lateinit var cancel: Button
    private lateinit var watch: Button
    private lateinit var share: Button
    private lateinit var bar: ProgressBar
    private lateinit var handCheck: CheckBox
    private lateinit var handInfo: TextView
    private lateinit var seekDur: SeekBar
    private lateinit var seekHand: SeekBar
    private lateinit var seekSpeed: SeekBar
    private lateinit var spStyle: Spinner
    private lateinit var spDir: Spinner
    private lateinit var spPaper: Spinner
    private lateinit var spRatio: Spinner
    private lateinit var spRes: Spinner
    private lateinit var spHold: Spinner
    private lateinit var spFps: Spinner
    private lateinit var spSens: Spinner
    private lateinit var spSource: Spinner
    private lateinit var spThick: Spinner

    private val cPrimary = 0xFF6C4CF1.toInt()
    private val cTeal = 0xFF00B8A9.toInt()
    private val cBg = 0xFFF3F4FA.toInt()
    private val cText = 0xFF1F2340.toInt()
    private val cMuted = 0xFF6B7194.toInt()
    private val cField = 0xFFF1F3F8.toInt()
    private val cDanger = 0xFFE5484D.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun lp(top: Int = 0, h: Int = -2) = LinearLayout.LayoutParams(-1, h).apply { topMargin = dp(top) }

    private fun card(parent: LinearLayout, emoji: String, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 18)
            elevation = dp(3).toFloat()
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        c.addView(TextView(this).apply {
            text = "$emoji  $title"; textSize = 16f; setTypeface(typeface, Typeface.BOLD); setTextColor(cText)
        })
        parent.addView(c, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(10), dp(14), dp(0)) })
        return c
    }

    private fun button(text: String, bg: Int, fg: Int = Color.WHITE, stroke: Int = 0) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 15f; setTextColor(fg)
        background = rounded(bg, 14, stroke); stateListAnimator = null
        setPadding(dp(16), dp(12), dp(16), dp(12))
    }

    private fun spinner(p: LinearLayout, label: String, items: List<String>, sel: Int = 0): Spinner {
        p.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(cMuted); setPadding(dp(2), dp(10), 0, dp(4)) })
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(sel)
        val box = FrameLayout(this).apply { background = rounded(cField, 12); setPadding(dp(6), 0, dp(6), 0) }
        box.addView(sp, FrameLayout.LayoutParams(-1, dp(46)))
        p.addView(box)
        return sp
    }

    private fun seekRow(p: LinearLayout, label: (Int) -> String, mx: Int, init: Int): SeekBar {
        val tv = TextView(this).apply { text = label(init); textSize = 13f; setTextColor(cText); setPadding(dp(2), dp(12), 0, 0) }
        val sb = SeekBar(this).apply {
            max = mx; progress = init
            progressTintList = ColorStateList.valueOf(cPrimary)
            thumbTintList = ColorStateList.valueOf(cPrimary)
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { tv.text = label(v) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        p.addView(tv); p.addView(sb)
        return sb
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = cPrimary
        window.navigationBarColor = cBg
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(28)) }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(30))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(cPrimary, cTeal)).apply {
                val r = dp(28).toFloat()
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
        }
        header.addView(TextView(this).apply {
            text = "\uD83C\uDFA8 SpeedPaint"; textSize = 28f; setTypeface(typeface, Typeface.BOLD); setTextColor(Color.WHITE)
        })
        header.addView(TextView(this).apply {
            text = "Ubah foto jadi video menggambar"; textSize = 14f; setTextColor(0xE6FFFFFF.toInt()); setPadding(0, dp(4), 0, 0)
        })
        col.addView(header)

        // 1. Foto
        val c1 = card(col, "\uD83D\uDDBC\uFE0F", "Foto")
        val pick = button("Pilih Foto", cPrimary)
        c1.addView(pick, lp(10, dp(50)))
        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        val hint = TextView(this).apply { text = "Belum ada foto"; setTextColor(cMuted); gravity = Gravity.CENTER }
        val pbox = FrameLayout(this).apply { background = rounded(cField, 14); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        pbox.addView(hint, FrameLayout.LayoutParams(-1, -1))
        pbox.addView(preview, FrameLayout.LayoutParams(-1, -1))
        photoHint = hint
        c1.addView(pbox, lp(12, dp(220)))

        // 2. Gaya
        val c2 = card(col, "\u270F\uFE0F", "Gaya menggambar")
        spStyle = spinner(c2, "Gaya", listOf("Ikuti garis, lalu warna", "Langsung warna (menyapu)", "Ikuti garis saja"))
        spDir = spinner(c2, "Arah", listOf("Kiri ke kanan", "Atas ke bawah", "Dari tengah keluar"))
        spPaper = spinner(c2, "Latar kertas", listOf("Putih", "Krem", "Papan tulis"))

        // 3. Video
        val c3 = card(col, "\uD83C\uDFAC", "Video")
        seekDur = seekRow(c3, { "Durasi: ${it + 5} detik" }, 55, 10)
        spRatio = spinner(c3, "Rasio video", listOf("Sesuai foto", "9:16 (Reels/TikTok)", "1:1 (Instagram)", "16:9 (YouTube)"))
        spRes = spinner(c3, "Resolusi", listOf("720p", "1080p"))
        spFps = spinner(c3, "FPS video", listOf("24 fps", "30 fps", "60 fps"), 1)
        spHold = spinner(c3, "Tahan hasil akhir", listOf("0 detik", "1 detik", "2 detik", "3 detik"), 1)

        // 4. Garis
        val c4 = card(col, "\u3030\uFE0F", "Deteksi garis")
        spSource = spinner(c4, "Sumber garis", listOf("Otomatis (hitam-putih / foto)", "Tepi saja (untuk foto)", "Area gelap (gambar hitam-putih)"))
        spSens = spinner(c4, "Kepekaan garis", listOf("Otomatis (sesuai gambar)", "Lebih sedikit garis", "Lebih banyak garis"))
        spThick = spinner(c4, "Ketebalan garis", listOf("Otomatis (sesuai gambar)", "Tipis", "Sedang", "Tebal"))

        // 5. Tangan
        val c5 = card(col, "\u270B", "Tangan")
        handCheck = CheckBox(this).apply {
            text = "Tampilkan gambar tangan"; isChecked = true; setTextColor(cText)
            buttonTintList = ColorStateList.valueOf(cPrimary)
        }
        c5.addView(handCheck, lp(6))
        seekHand = seekRow(c5, { "Ukuran tangan: ${it + 20}%" }, 80, 35)
        seekSpeed = seekRow(c5, { "Kecepatan gerak tangan: x${(it + 5) / 10f}" }, 25, 5)
        handInfo = TextView(this).apply { textSize = 12f; setTextColor(cMuted); setPadding(dp(2), dp(10), 0, 0) }
        c5.addView(handInfo)
        val handBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val loadHandBtn = button("Ganti tangan (PNG)", Color.WHITE, cPrimary, cPrimary)
        val resetHandBtn = button("Bawaan", Color.WHITE, cPrimary, cPrimary)
        handBtns.addView(loadHandBtn, LinearLayout.LayoutParams(0, dp(46), 2f).apply { rightMargin = dp(8) })
        handBtns.addView(resetHandBtn, LinearLayout.LayoutParams(0, dp(46), 1f))
        c5.addView(handBtns, lp(10))

        // Aksi
        val act = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(16), dp(14), 0) }
        generate = button("\u25B6  Buat Video Speedpaint", cPrimary).apply { isEnabled = false; textSize = 17f; alpha = 0.5f }
        cancel = button("Batalkan", Color.WHITE, cDanger, cDanger).apply { visibility = View.GONE }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE; progressTintList = ColorStateList.valueOf(cPrimary)
        }
        status = TextView(this).apply { gravity = Gravity.CENTER; setTextColor(cText); textSize = 14f }
        watch = button("Putar Video", cTeal).apply { visibility = View.GONE }
        share = button("Bagikan", Color.WHITE, cPrimary, cPrimary).apply { visibility = View.GONE }
        act.addView(generate, lp(0, dp(58)))
        act.addView(cancel, lp(8, dp(48)))
        act.addView(bar, lp(12))
        act.addView(status, lp(8))
        act.addView(watch, lp(10, dp(50)))
        act.addView(share, lp(8, dp(50)))
        col.addView(act)

        setContentView(ScrollView(this).apply { setBackgroundColor(cBg); addView(col) })
        refreshHandInfo()
        handCheck.setOnCheckedChangeListener { _, on ->
            seekHand.isEnabled = on; seekSpeed.isEnabled = on
            loadHandBtn.isEnabled = on; resetHandBtn.isEnabled = on
            loadHandBtn.alpha = if (on) 1f else 0.4f; resetHandBtn.alpha = if (on) 1f else 0.4f
        }

        pick.setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 1) }
        loadHandBtn.setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 2) }
        resetHandBtn.setOnClickListener { File(filesDir, "hand_custom.png").delete(); refreshHandInfo() }
        generate.setOnClickListener { startRender() }
        cancel.setOnClickListener { cancelFlag = true; status.text = "Membatalkan..." }
        watch.setOnClickListener {
            resultUri?.let {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }
        share.setOnClickListener {
            resultUri?.let {
                val i = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, it)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(i, "Bagikan video"))
            }
        }
    }

    private fun refreshHandInfo() {
        handInfo.text = if (File(filesDir, "hand_custom.png").exists()) "Tangan: gambar pilihan Anda" else "Tangan: bawaan"
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (req == 1) {
            bitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, _, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
            preview.setImageBitmap(bitmap)
            generate.isEnabled = true
            generate.alpha = 1f
            photoHint.visibility = View.GONE
            watch.visibility = View.GONE
            share.visibility = View.GONE
        } else if (req == 2) {
            val f = File(filesDir, "hand_custom.png")
            try {
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, bo)
                if (bo.outWidth <= 0) { f.delete(); Toast.makeText(this, "File bukan gambar", Toast.LENGTH_SHORT).show() }
            } catch (e: Exception) {
                f.delete(); Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_SHORT).show()
            }
            refreshHandInfo()
        }
    }

    private fun loadHand(): Bitmap? {
        if (!handCheck.isChecked) return null
        val f = File(filesDir, "hand_custom.png")
        if (f.exists()) {
            val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bo)
            val ss = max(1, bo.outWidth / 1600)
            return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = ss })
        }
        val id = resources.getIdentifier("hand", "drawable", packageName)
        return if (id != 0) BitmapFactory.decodeResource(resources, id) else null
    }

    private fun startRender() {
        val bmp = bitmap ?: return
        val secs = seekDur.progress + 5
        val opts = PaintOptions(
            style = spStyle.selectedItemPosition,
            direction = spDir.selectedItemPosition,
            paper = spPaper.selectedItemPosition,
            ratio = spRatio.selectedItemPosition,
            res = if (spRes.selectedItemPosition == 1) 1080 else 720,
            handPct = seekHand.progress + 20,
            handSpeed = (seekSpeed.progress + 5) / 10f,
            holdSec = spHold.selectedItemPosition,
            fps = intArrayOf(24, 30, 60)[spFps.selectedItemPosition],
            sens = spSens.selectedItemPosition,
            thick = spThick.selectedItemPosition,
            source = spSource.selectedItemPosition
        )
        val hand = loadHand()
        cancelFlag = false
        generate.isEnabled = false
        generate.alpha = 0.5f
        cancel.visibility = View.VISIBLE
        watch.visibility = View.GONE
        share.visibility = View.GONE
        bar.progress = 0
        bar.visibility = View.VISIBLE
        status.text = "Membuat video..."
        Thread {
            try {
                val tmp = File(cacheDir, "speedpaint.mp4")
                SpeedPaint.render(bmp, secs, tmp, opts, hand, { cancelFlag }) { p -> runOnUiThread { bar.progress = p } }
                if (cancelFlag) {
                    tmp.delete()
                    runOnUiThread { status.text = "Dibatalkan" }
                } else {
                    val cv = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "speedpaint_${System.currentTimeMillis()}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SpeedPaint")
                    }
                    val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
                    contentResolver.openOutputStream(uri)!!.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                    resultUri = uri
                    runOnUiThread {
                        status.text = "Selesai! Tersimpan di Movies/SpeedPaint"
                        watch.visibility = View.VISIBLE
                        share.visibility = View.VISIBLE
                    }
                }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Gagal: ${e.message}" }
            } finally {
                runOnUiThread { generate.isEnabled = true; generate.alpha = 1f; cancel.visibility = View.GONE; bar.visibility = View.GONE }
            }
        }.start()
    }
}
